<?php
/*
Plugin Name: Warthog Speed Booster
Description: Enhance your website's speed with Warthog Speed Booster by enabling caching, minifying scripts, and lazy loading images.
Version: 1.0
Author: ShopsFargo
Author URI: https://x.com/ShopsFargoes
*/

// Enable Browser Caching
function warthog_enable_browser_caching() {
    if (!is_admin()) {
        header("Cache-Control: public, max-age=31536000");
    }
}
add_action('send_headers', 'warthog_enable_browser_caching');

// Minify JavaScript and CSS
function warthog_minify_scripts() {
    // Minify JavaScript
    function warthog_minify_js($src) {
        if (strpos($src, '.js')) {
            return str_replace(array("\n", "\t", '  '), '', $src);
        }
        return $src;
    }
    // Minify CSS
    function warthog_minify_css($src) {
        if (strpos($src, '.css')) {
            return str_replace(array("\n", "\t", '  '), '', $src);
        }
        return $src;
    }

    // Add filters
    ob_start(function ($buffer) {
        $buffer = warthog_minify_js($buffer);
        $buffer = warthog_minify_css($buffer);
        return $buffer;
    });
}
add_action('template_redirect', 'warthog_minify_scripts');

// Enable Lazy Loading for Images
function warthog_lazy_load_images($content) {
    if (is_singular()) {
        $content = preg_replace('/<img(.*?)src=/', '<img$1loading="lazy" src=', $content);
    }
    return $content;
}
add_filter('the_content', 'warthog_lazy_load_images');
